var modules =
[
    [ "OCaml Language Interface", "group__PPL__OCaml__interface.html", null ],
    [ "C++ Language Interface", "../ppl-user-0.12.1-html/group__PPL__CXX__interface.html", "group__PPL__CXX__interface" ]
];