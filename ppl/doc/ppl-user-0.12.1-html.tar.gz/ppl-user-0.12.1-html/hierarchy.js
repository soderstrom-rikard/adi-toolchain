var hierarchy =
[
    [ "Parma_Polyhedra_Library::Approximable_Reference", "classParma__Polyhedra__Library_1_1Approximable__Reference.html", null ],
    [ "Parma_Polyhedra_Library::Approximable_Reference_Common< Target >", "classParma__Polyhedra__Library_1_1Approximable__Reference__Common.html", null ],
    [ "Parma_Polyhedra_Library::BD_Shape< T >", "classParma__Polyhedra__Library_1_1BD__Shape.html", null ],
    [ "Parma_Polyhedra_Library::BHRZ03_Certificate", "classParma__Polyhedra__Library_1_1BHRZ03__Certificate.html", null ],
    [ "Parma_Polyhedra_Library::Binary_Operator", "classParma__Polyhedra__Library_1_1Binary__Operator.html", null ],
    [ "Parma_Polyhedra_Library::Binary_Operator_Common< Target >", "classParma__Polyhedra__Library_1_1Binary__Operator__Common.html", null ],
    [ "Parma_Polyhedra_Library::Box< ITV >", "classParma__Polyhedra__Library_1_1Box.html", null ],
    [ "Parma_Polyhedra_Library::Cast_Operator", "classParma__Polyhedra__Library_1_1Cast__Operator.html", null ],
    [ "Parma_Polyhedra_Library::Cast_Operator_Common< Target >", "classParma__Polyhedra__Library_1_1Cast__Operator__Common.html", null ],
    [ "Parma_Polyhedra_Library::Checked_Number< T, Policy >", "classParma__Polyhedra__Library_1_1Checked__Number.html", null ],
    [ "Parma_Polyhedra_Library::BHRZ03_Certificate::Compare", "structParma__Polyhedra__Library_1_1BHRZ03__Certificate_1_1Compare.html", null ],
    [ "Parma_Polyhedra_Library::H79_Certificate::Compare", "structParma__Polyhedra__Library_1_1H79__Certificate_1_1Compare.html", null ],
    [ "Parma_Polyhedra_Library::Grid_Certificate::Compare", "structParma__Polyhedra__Library_1_1Grid__Certificate_1_1Compare.html", null ],
    [ "Parma_Polyhedra_Library::Variable::Compare", "structParma__Polyhedra__Library_1_1Variable_1_1Compare.html", null ],
    [ "Parma_Polyhedra_Library::Concrete_Expression", "classParma__Polyhedra__Library_1_1Concrete__Expression.html", null ],
    [ "Parma_Polyhedra_Library::Concrete_Expression_Common< Target >", "classParma__Polyhedra__Library_1_1Concrete__Expression__Common.html", null ],
    [ "Parma_Polyhedra_Library::Concrete_Expression_Type", "classParma__Polyhedra__Library_1_1Concrete__Expression__Type.html", null ],
    [ "Parma_Polyhedra_Library::Congruence", "classParma__Polyhedra__Library_1_1Congruence.html", null ],
    [ "Parma_Polyhedra_Library::Congruence_System", "classParma__Polyhedra__Library_1_1Congruence__System.html", null ],
    [ "Parma_Polyhedra_Library::Congruences_Reduction< D1, D2 >", "classParma__Polyhedra__Library_1_1Congruences__Reduction.html", null ],
    [ "Parma_Polyhedra_Library::Constraint_System::const_iterator", "classParma__Polyhedra__Library_1_1Constraint__System_1_1const__iterator.html", null ],
    [ "Parma_Polyhedra_Library::Congruence_System::const_iterator", "classParma__Polyhedra__Library_1_1Congruence__System_1_1const__iterator.html", null ],
    [ "Parma_Polyhedra_Library::Generator_System::const_iterator", "classParma__Polyhedra__Library_1_1Generator__System_1_1const__iterator.html", [
      [ "Parma_Polyhedra_Library::Grid_Generator_System::const_iterator", "classParma__Polyhedra__Library_1_1Grid__Generator__System_1_1const__iterator.html", null ]
    ] ],
    [ "Parma_Polyhedra_Library::CO_Tree::const_iterator", "classParma__Polyhedra__Library_1_1CO__Tree_1_1const__iterator.html", null ],
    [ "Parma_Polyhedra_Library::MIP_Problem::const_iterator", "classParma__Polyhedra__Library_1_1MIP__Problem_1_1const__iterator.html", null ],
    [ "Parma_Polyhedra_Library::Constraint", "classParma__Polyhedra__Library_1_1Constraint.html", null ],
    [ "Parma_Polyhedra_Library::Constraint_System", "classParma__Polyhedra__Library_1_1Constraint__System.html", null ],
    [ "Parma_Polyhedra_Library::Constraints_Reduction< D1, D2 >", "classParma__Polyhedra__Library_1_1Constraints__Reduction.html", null ],
    [ "Parma_Polyhedra_Library::Determinate< PSET >", "classParma__Polyhedra__Library_1_1Determinate.html", null ],
    [ "Parma_Polyhedra_Library::Domain_Product< D1, D2 >", "classParma__Polyhedra__Library_1_1Domain__Product.html", null ],
    [ "Parma_Polyhedra_Library::Implementation::Watchdog::Doubly_Linked_Object", "classParma__Polyhedra__Library_1_1Implementation_1_1Watchdog_1_1Doubly__Linked__Object.html", [
      [ "Parma_Polyhedra_Library::Implementation::Watchdog::EList< T >", "classParma__Polyhedra__Library_1_1Implementation_1_1Watchdog_1_1EList.html", null ],
      [ "Parma_Polyhedra_Library::Implementation::Watchdog::Pending_Element< Threshold >", "classParma__Polyhedra__Library_1_1Implementation_1_1Watchdog_1_1Pending__Element.html", null ]
    ] ],
    [ "Parma_Polyhedra_Library::Implementation::Watchdog::EList_Iterator< T >", "classParma__Polyhedra__Library_1_1Implementation_1_1Watchdog_1_1EList__Iterator.html", null ],
    [ "Parma_Polyhedra_Library::Floating_Point_Constant", "classParma__Polyhedra__Library_1_1Floating__Point__Constant.html", null ],
    [ "Parma_Polyhedra_Library::Floating_Point_Constant_Common< Target >", "classParma__Polyhedra__Library_1_1Floating__Point__Constant__Common.html", null ],
    [ "Parma_Polyhedra_Library::Floating_Point_Expression< FP_Interval_Type, FP_Format >", "classParma__Polyhedra__Library_1_1Floating__Point__Expression.html", [
      [ "Parma_Polyhedra_Library::Cast_Floating_Point_Expression< FP_Interval_Type, FP_Format >", "classParma__Polyhedra__Library_1_1Cast__Floating__Point__Expression.html", null ],
      [ "Parma_Polyhedra_Library::Constant_Floating_Point_Expression< FP_Interval_Type, FP_Format >", "classParma__Polyhedra__Library_1_1Constant__Floating__Point__Expression.html", null ],
      [ "Parma_Polyhedra_Library::Difference_Floating_Point_Expression< FP_Interval_Type, FP_Format >", "classParma__Polyhedra__Library_1_1Difference__Floating__Point__Expression.html", null ],
      [ "Parma_Polyhedra_Library::Division_Floating_Point_Expression< FP_Interval_Type, FP_Format >", "classParma__Polyhedra__Library_1_1Division__Floating__Point__Expression.html", null ],
      [ "Parma_Polyhedra_Library::Multiplication_Floating_Point_Expression< FP_Interval_Type, FP_Format >", "classParma__Polyhedra__Library_1_1Multiplication__Floating__Point__Expression.html", null ],
      [ "Parma_Polyhedra_Library::Opposite_Floating_Point_Expression< FP_Interval_Type, FP_Format >", "classParma__Polyhedra__Library_1_1Opposite__Floating__Point__Expression.html", null ],
      [ "Parma_Polyhedra_Library::Sum_Floating_Point_Expression< FP_Interval_Type, FP_Format >", "classParma__Polyhedra__Library_1_1Sum__Floating__Point__Expression.html", null ],
      [ "Parma_Polyhedra_Library::Variable_Floating_Point_Expression< FP_Interval_Type, FP_Format >", "classParma__Polyhedra__Library_1_1Variable__Floating__Point__Expression.html", null ]
    ] ],
    [ "Parma_Polyhedra_Library::FP_Oracle< Target, FP_Interval_Type >", "classParma__Polyhedra__Library_1_1FP__Oracle.html", null ],
    [ "Parma_Polyhedra_Library::Generator", "classParma__Polyhedra__Library_1_1Generator.html", [
      [ "Parma_Polyhedra_Library::Grid_Generator", "classParma__Polyhedra__Library_1_1Grid__Generator.html", null ]
    ] ],
    [ "Parma_Polyhedra_Library::Generator_System", "classParma__Polyhedra__Library_1_1Generator__System.html", [
      [ "Parma_Polyhedra_Library::Grid_Generator_System", "classParma__Polyhedra__Library_1_1Grid__Generator__System.html", null ]
    ] ],
    [ "Parma_Polyhedra_Library::GMP_Integer", "classParma__Polyhedra__Library_1_1GMP__Integer.html", null ],
    [ "Parma_Polyhedra_Library::Grid", "classParma__Polyhedra__Library_1_1Grid.html", null ],
    [ "Parma_Polyhedra_Library::Grid_Certificate", "classParma__Polyhedra__Library_1_1Grid__Certificate.html", null ],
    [ "Parma_Polyhedra_Library::H79_Certificate", "classParma__Polyhedra__Library_1_1H79__Certificate.html", null ],
    [ "Parma_Polyhedra_Library::Implementation::Watchdog::Handler", "classParma__Polyhedra__Library_1_1Implementation_1_1Watchdog_1_1Handler.html", [
      [ "Parma_Polyhedra_Library::Implementation::Watchdog::Handler_Flag< Flag_Base, Flag >", "classParma__Polyhedra__Library_1_1Implementation_1_1Watchdog_1_1Handler__Flag.html", null ],
      [ "Parma_Polyhedra_Library::Implementation::Watchdog::Handler_Function", "classParma__Polyhedra__Library_1_1Implementation_1_1Watchdog_1_1Handler__Function.html", null ]
    ] ],
    [ "Parma_Polyhedra_Library::Integer_Constant", "classParma__Polyhedra__Library_1_1Integer__Constant.html", null ],
    [ "Parma_Polyhedra_Library::Integer_Constant_Common< Target >", "classParma__Polyhedra__Library_1_1Integer__Constant__Common.html", null ],
    [ "Parma_Polyhedra_Library::Interval< Boundary, Info >", "classParma__Polyhedra__Library_1_1Interval.html", null ],
    [ "Parma_Polyhedra_Library::CO_Tree::iterator", "classParma__Polyhedra__Library_1_1CO__Tree_1_1iterator.html", null ],
    [ "Parma_Polyhedra_Library::Linear_Expression", "classParma__Polyhedra__Library_1_1Linear__Expression.html", [
      [ "Parma_Polyhedra_Library::PIP_Tree_Node::Artificial_Parameter", "classParma__Polyhedra__Library_1_1PIP__Tree__Node_1_1Artificial__Parameter.html", null ]
    ] ],
    [ "Parma_Polyhedra_Library::Linear_Form< C >", "classParma__Polyhedra__Library_1_1Linear__Form.html", null ],
    [ "Parma_Polyhedra_Library::MIP_Problem", "classParma__Polyhedra__Library_1_1MIP__Problem.html", null ],
    [ "Parma_Polyhedra_Library::PIP_Solution_Node::No_Constraints", "structParma__Polyhedra__Library_1_1PIP__Solution__Node_1_1No__Constraints.html", null ],
    [ "Parma_Polyhedra_Library::No_Reduction< D1, D2 >", "classParma__Polyhedra__Library_1_1No__Reduction.html", null ],
    [ "Parma_Polyhedra_Library::Octagonal_Shape< T >", "classParma__Polyhedra__Library_1_1Octagonal__Shape.html", null ],
    [ "Parma_Polyhedra_Library::Partially_Reduced_Product< D1, D2, R >", "classParma__Polyhedra__Library_1_1Partially__Reduced__Product.html", null ],
    [ "Parma_Polyhedra_Library::Implementation::Watchdog::Pending_List< Traits >", "classParma__Polyhedra__Library_1_1Implementation_1_1Watchdog_1_1Pending__List.html", null ],
    [ "Parma_Polyhedra_Library::PIP_Problem", "classParma__Polyhedra__Library_1_1PIP__Problem.html", null ],
    [ "Parma_Polyhedra_Library::PIP_Tree_Node", "classParma__Polyhedra__Library_1_1PIP__Tree__Node.html", [
      [ "Parma_Polyhedra_Library::PIP_Decision_Node", "classParma__Polyhedra__Library_1_1PIP__Decision__Node.html", null ],
      [ "Parma_Polyhedra_Library::PIP_Solution_Node", "classParma__Polyhedra__Library_1_1PIP__Solution__Node.html", null ]
    ] ],
    [ "Parma_Polyhedra_Library::Poly_Con_Relation", "classParma__Polyhedra__Library_1_1Poly__Con__Relation.html", null ],
    [ "Parma_Polyhedra_Library::Poly_Gen_Relation", "classParma__Polyhedra__Library_1_1Poly__Gen__Relation.html", null ],
    [ "Parma_Polyhedra_Library::Polyhedron", "classParma__Polyhedra__Library_1_1Polyhedron.html", [
      [ "Parma_Polyhedra_Library::C_Polyhedron", "classParma__Polyhedra__Library_1_1C__Polyhedron.html", null ],
      [ "Parma_Polyhedra_Library::NNC_Polyhedron", "classParma__Polyhedra__Library_1_1NNC__Polyhedron.html", null ]
    ] ],
    [ "Parma_Polyhedra_Library::Powerset< D >", "classParma__Polyhedra__Library_1_1Powerset.html", null ],
    [ "Parma_Polyhedra_Library::Powerset< Parma_Polyhedra_Library::Determinate< PSET > >", "classParma__Polyhedra__Library_1_1Powerset.html", [
      [ "Parma_Polyhedra_Library::Pointset_Powerset< PSET >", "classParma__Polyhedra__Library_1_1Pointset__Powerset.html", null ]
    ] ],
    [ "Parma_Polyhedra_Library::Recycle_Input", "structParma__Polyhedra__Library_1_1Recycle__Input.html", null ],
    [ "Parma_Polyhedra_Library::Shape_Preserving_Reduction< D1, D2 >", "classParma__Polyhedra__Library_1_1Shape__Preserving__Reduction.html", null ],
    [ "Parma_Polyhedra_Library::Smash_Reduction< D1, D2 >", "classParma__Polyhedra__Library_1_1Smash__Reduction.html", null ],
    [ "Parma_Polyhedra_Library::Threshold_Watcher< Traits >", "classParma__Polyhedra__Library_1_1Threshold__Watcher.html", null ],
    [ "Parma_Polyhedra_Library::Throwable", "classParma__Polyhedra__Library_1_1Throwable.html", null ],
    [ "Parma_Polyhedra_Library::Implementation::Watchdog::Time", "classParma__Polyhedra__Library_1_1Implementation_1_1Watchdog_1_1Time.html", null ],
    [ "Parma_Polyhedra_Library::Unary_Operator", "classParma__Polyhedra__Library_1_1Unary__Operator.html", null ],
    [ "Parma_Polyhedra_Library::Unary_Operator_Common< Target >", "classParma__Polyhedra__Library_1_1Unary__Operator__Common.html", null ],
    [ "Parma_Polyhedra_Library::Variable", "classParma__Polyhedra__Library_1_1Variable.html", null ],
    [ "Parma_Polyhedra_Library::Variables_Set", "classParma__Polyhedra__Library_1_1Variables__Set.html", null ],
    [ "Parma_Polyhedra_Library::Watchdog", "classParma__Polyhedra__Library_1_1Watchdog.html", null ]
];