var group__Error =
[
    [ "ppl_enum_error_code", "group__Error.html#ga0c0ab09a97e49f85f42c966e14cfdee6", null ],
    [ "ppl_set_error_handler", "group__Error.html#gad6765993c08a2ae2f0ef377f822f4d33", null ]
];