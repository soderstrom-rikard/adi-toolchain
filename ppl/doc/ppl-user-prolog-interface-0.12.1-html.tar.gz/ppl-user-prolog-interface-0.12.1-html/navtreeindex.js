var NAVTREEINDEX =
{
"index.html":[],
"index.html":[0],
"GPL_different_HTML_tag.html":[1],
"GFDL_different_HTML_tag.html":[2],
"PI_SI_Features.html":[3],
"domains_predicates.html":[4],
"PI_Compilation.html":[5],
"PI_SD_Features.html":[6],
"modules.html":[7],
"group__PPL__Prolog__interface.html":[7,0],
"group__PPL__CXX__interface.html":[7,1]
};
