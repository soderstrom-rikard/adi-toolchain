var classparma__polyhedra__library_1_1Parma__Polyhedra__Library =
[
    [ "initialize_library", "classparma__polyhedra__library_1_1Parma__Polyhedra__Library.html#a65283b563ec02a47928cc176c738f78b", null ],
    [ "finalize_library", "classparma__polyhedra__library_1_1Parma__Polyhedra__Library.html#a4e5e7fc32bfd0ae986d63ec82db62f6a", null ],
    [ "version_major", "classparma__polyhedra__library_1_1Parma__Polyhedra__Library.html#a0c349132b447b3e6a5234a23257f417d", null ],
    [ "version_minor", "classparma__polyhedra__library_1_1Parma__Polyhedra__Library.html#a6b7d95f94c10fe3747eff2a3e05f9d32", null ],
    [ "version_revision", "classparma__polyhedra__library_1_1Parma__Polyhedra__Library.html#ac555ee6fa79c8a4d49f8ce2a14ca1cf6", null ],
    [ "version_beta", "classparma__polyhedra__library_1_1Parma__Polyhedra__Library.html#aa8876ac784666f054f546f48404cb27a", null ],
    [ "version", "classparma__polyhedra__library_1_1Parma__Polyhedra__Library.html#ab6bcd066e77a3dde5c6127ac6dfabfa7", null ],
    [ "banner", "classparma__polyhedra__library_1_1Parma__Polyhedra__Library.html#ae763a3d0db8c57898dff5ba199ea87e5", null ],
    [ "set_rounding_for_PPL", "classparma__polyhedra__library_1_1Parma__Polyhedra__Library.html#a805ae2717e65749d104d71978ed97fa4", null ],
    [ "restore_pre_PPL_rounding", "classparma__polyhedra__library_1_1Parma__Polyhedra__Library.html#a7a8ac14db1f77aaa2e88fb7148633f7e", null ],
    [ "irrational_precision", "classparma__polyhedra__library_1_1Parma__Polyhedra__Library.html#a08c3b1c1c4e916f10c85114ac888c040", null ],
    [ "set_irrational_precision", "classparma__polyhedra__library_1_1Parma__Polyhedra__Library.html#af46aeb04c5a5a83a60ddf1a280c8b648", null ],
    [ "set_timeout", "classparma__polyhedra__library_1_1Parma__Polyhedra__Library.html#afb7d3612f1ec7e7432a4168ea245f0f9", null ],
    [ "reset_timeout", "classparma__polyhedra__library_1_1Parma__Polyhedra__Library.html#aa8ff36c02349f02bdf1d374823cb4590", null ],
    [ "set_deterministic_timeout", "classparma__polyhedra__library_1_1Parma__Polyhedra__Library.html#a5223af806da56cfe9a7c6ed71b4a0604", null ],
    [ "reset_deterministic_timeout", "classparma__polyhedra__library_1_1Parma__Polyhedra__Library.html#a903afb11ccb24f752fc0bf2b430b16c2", null ]
];