var classparma__polyhedra__library_1_1PIP__Solution__Node =
[
    [ "parametric_values", "classparma__polyhedra__library_1_1PIP__Solution__Node.html#ab532119425bcb15a8c6063d19f071c3c", null ]
];