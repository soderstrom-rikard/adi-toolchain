var classparma__polyhedra__library_1_1Poly__Con__Relation =
[
    [ "Poly_Con_Relation", "classparma__polyhedra__library_1_1Poly__Con__Relation.html#ae9b4bcc84019980d7be4ace75e54c0b3", null ],
    [ "nothing", "classparma__polyhedra__library_1_1Poly__Con__Relation.html#a31e5a38eb5511d477ccd1b793fec470b", null ],
    [ "is_disjoint", "classparma__polyhedra__library_1_1Poly__Con__Relation.html#ab038d193cd145f2bc59b501db605e320", null ],
    [ "strictly_intersects", "classparma__polyhedra__library_1_1Poly__Con__Relation.html#a44dd34b28b7e0ca0ea892e9259ea7103", null ],
    [ "is_included", "classparma__polyhedra__library_1_1Poly__Con__Relation.html#a4358da8086e7af078f42a62c817895e3", null ],
    [ "saturates", "classparma__polyhedra__library_1_1Poly__Con__Relation.html#afc62e3c93daf5e744e4b3e450c7c7270", null ],
    [ "implies", "classparma__polyhedra__library_1_1Poly__Con__Relation.html#adc93ada4ec022b8e6020c91412e0b0ef", null ],
    [ "NOTHING", "classparma__polyhedra__library_1_1Poly__Con__Relation.html#af438fb04bc9d5e29e3e83ac650b58599", null ],
    [ "IS_DISJOINT", "classparma__polyhedra__library_1_1Poly__Con__Relation.html#a6bbb442c69c721cfda0009f664d58b87", null ],
    [ "STRICTLY_INTERSECTS", "classparma__polyhedra__library_1_1Poly__Con__Relation.html#a962957c7c36848ff1b1ced9ba37ce5f2", null ],
    [ "IS_INCLUDED", "classparma__polyhedra__library_1_1Poly__Con__Relation.html#a51b88a0037947dea4974c0996763f497", null ],
    [ "SATURATES", "classparma__polyhedra__library_1_1Poly__Con__Relation.html#af1118753cb062e6761a655b7975718f7", null ]
];