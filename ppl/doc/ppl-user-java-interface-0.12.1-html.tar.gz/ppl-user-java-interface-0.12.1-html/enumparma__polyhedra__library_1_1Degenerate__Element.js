var enumparma__polyhedra__library_1_1Degenerate__Element =
[
    [ "[static initializer]", "enumparma__polyhedra__library_1_1Degenerate__Element.html#a8bfb012373348f71b09cb7a58c7abe93", null ],
    [ "UNIVERSE", "enumparma__polyhedra__library_1_1Degenerate__Element.html#a9ff8417659bb4800d825f91fa8685aaf", null ]
];