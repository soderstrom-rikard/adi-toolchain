var enumparma__polyhedra__library_1_1Bounded__Integer__Type__Representation =
[
    [ "[static initializer]", "enumparma__polyhedra__library_1_1Bounded__Integer__Type__Representation.html#a8f1f56921bb4674709c9cb9747e6fda6", null ],
    [ "UNSIGNED", "enumparma__polyhedra__library_1_1Bounded__Integer__Type__Representation.html#a5989bf59e335673996e366dbea747064", null ]
];